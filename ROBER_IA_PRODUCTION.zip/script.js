
const respostas = {
    "oi": "Olá! Como posso ajudar?",
    "tudo bem": "Tudo ótimo! E com você?",
    "qual seu nome": "Meu nome é Rober IA!",
    "quem te criou": "Fui desenvolvido por um humano muito inteligente!",
    "o que você faz": "Eu te ajudo respondendo perguntas e interagindo.",
    "qual a capital do brasil": "Brasília é a capital do Brasil.",
    "me conta uma piada": "Por que o jacaré tirou o filho da escola? Porque ele réptil de ano!",
    "quem descobriu o brasil": "Foi Pedro Álvares Cabral em 1500.",
};

const chat = document.getElementById('chat');

function enviar() {
    const entrada = document.getElementById('entrada');
    const texto = entrada.value.trim();
    if (texto === "") return;

    adicionarMensagem("Você", texto, "eu");

    const resposta = processarPergunta(texto.toLowerCase());
    setTimeout(() => {
        adicionarMensagem("ROBER IA", resposta, "ia");
    }, 500);

    entrada.value = "";
}

function processarPergunta(pergunta) {
    try {
        const conta = pergunta
            .replace('quanto é', '')
            .replace('calcule', '')
            .replace('raiz quadrada de', 'Math.sqrt')
            .replace('√', 'Math.sqrt')
            .replace('x', '*')
            .replace('dividido por', '/')
            .replace('mais', '+')
            .replace('menos', '-')
            .replace('vezes', '*')
            .replace('=', '')
            .replace('?', '')
            .trim();

        if (conta.includes('math.sqrt') || /[0-9+\-*/().]/.test(conta)) {
            const resultado = Function('"use strict";return (' + conta + ')')();
            if (!isNaN(resultado)) {
                return `O resultado é ${resultado}`;
            }
        }
    } catch {}

    return respostas[pergunta] || "Desculpe, não entendi. Pergunte outra coisa ou faça um cálculo!";
}

function adicionarMensagem(remetente, mensagem, classe) {
    const div = document.createElement('div');
    div.className = `msg ${classe}`;
    div.innerHTML = `<strong>${remetente}:</strong> ${mensagem}`;
    chat.appendChild(div);
    chat.scrollTop = chat.scrollHeight;
}

function limpar() {
    chat.innerHTML = "";
}

function figurinha() {
    const stickers = ["😊", "😂", "❤️", "👍", "🤖", "🔥", "🎉", "🙌", "🥳"];
    const sorteio = stickers[Math.floor(Math.random() * stickers.length)];
    adicionarMensagem("Você", sorteio, "eu");
    setTimeout(() => {
        adicionarMensagem("ROBER IA", sorteio, "ia");
    }, 500);
}

function voz() {
    const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
    recognition.lang = 'pt-BR';
    recognition.start();
    recognition.onresult = function(event) {
        const resultado = event.results[0][0].transcript;
        document.getElementById('entrada').value = resultado;
        enviar();
    };
}

function tocarMusica() {
    const musica = document.getElementById('musica');
    if (musica.paused) {
        musica.play();
        document.getElementById('musicaBtn').innerText = 'Pausar Música';
    } else {
        musica.pause();
        document.getElementById('musicaBtn').innerText = 'Música';
    }
}

function atualizarRelogio() {
    const agora = new Date();
    const horas = agora.getHours().toString().padStart(2, '0');
    const minutos = agora.getMinutes().toString().padStart(2, '0');
    const segundos = agora.getSeconds().toString().padStart(2, '0');
    document.getElementById('relogio').innerText = `${horas}:${minutos}:${segundos}`;
}
setInterval(atualizarRelogio, 1000);

window.onload = () => {
    setTimeout(() => {
        document.getElementById('carregando').style.display = 'none';
    }, 1500);
};
